﻿Option Strict On
Option Explicit On
Imports System.ComponentModel

Public Class AddName
    Dim player As New players


    Private Sub btnAddName_Click(sender As Object, e As EventArgs) Handles btnAddName.Click
        Dim playersList As New BindingList(Of players)
        If txtPlayerName.Text <> "" Then
            player.playerName = txtPlayerName.Text
            player.playerScore = CInt(MainFrm.score)
            MainFrm.playersList.Add(player)
            MainFrm.lstPlayers.Items.Add(player.playerName)
            playersList.Add(player)
            MainFrm.populateCombos()
            MainFrm.lblTotalScore.Text = ""
            MainFrm.score = 0
            Me.Close()
        Else
            MessageBox.Show("Plese enter your name")
        End If
    End Sub
End Class